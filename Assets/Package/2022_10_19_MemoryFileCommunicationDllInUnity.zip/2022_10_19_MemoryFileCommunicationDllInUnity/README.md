# 2022_10_19_MemoryFileCommunicationDllIUnity
Package that allows have Memory Map File communication in Unity with outside application from a DLL.

- https://github.com/EloiStree/2022_10_20_MemoryFileConnectionUtilityDLL
- https://github.com/EloiStree/2022_10_19_MemoryFileCommunicationDllInUnity
