using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace UnityMemoryFileCommunication4Unity
{
    public class MemoryFileConnectObserveAsTextMono : MonoBehaviour
    {
        public MemoryFileConnectionDLLMono m_observedDate   ;
        public bool m_flushWhenRead;
        public bool m_useUpdate;

        public string m_textPrevious;
        public string m_text;
        public UnityEvent m_onChange;

        public void Update()
        {
            if (m_useUpdate)
                Refresh();

        }

        private void Refresh()
        {
            m_observedDate.Connection.GetAsText(out m_text, m_flushWhenRead);
            if (Eloi.E_StringUtility.AreNotEquals(in m_text, in m_textPrevious, true, true))
            {
                m_onChange.Invoke();
            }
            m_textPrevious = m_text;
        }
        private void Reset()
        {
            m_observedDate = GetComponent<MemoryFileConnectionDLLMono>();
        }
    }
}