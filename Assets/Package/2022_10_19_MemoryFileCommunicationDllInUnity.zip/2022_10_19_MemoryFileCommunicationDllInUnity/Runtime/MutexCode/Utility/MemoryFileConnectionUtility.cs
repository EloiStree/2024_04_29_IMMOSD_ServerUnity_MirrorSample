﻿namespace MemoryFileConnectionUtility
{
    public class MemoryFileConnectionUtility {
        public  const int _1MOSize = 1000000;
        public const int _1KOSize=1000;
    }


}