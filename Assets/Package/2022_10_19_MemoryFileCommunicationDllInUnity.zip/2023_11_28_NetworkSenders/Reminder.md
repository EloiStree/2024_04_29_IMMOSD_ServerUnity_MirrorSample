For this tool, you need
https://github.com/endel/NativeWebSocket.git#upm

That Unity provide to have websocket in your project.