# 2023_11_28_NetworkSenders
Just some script to send UDP and Websocket message on network.
