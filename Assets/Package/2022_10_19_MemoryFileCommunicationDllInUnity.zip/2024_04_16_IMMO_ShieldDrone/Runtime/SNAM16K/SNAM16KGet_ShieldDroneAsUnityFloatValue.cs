﻿public class SNAM16KGet_ShieldDroneAsUnityFloatValue : SNAM_GetDebugGeneric16K<STRUCT_ShieldDroneAsUnity>
{

}