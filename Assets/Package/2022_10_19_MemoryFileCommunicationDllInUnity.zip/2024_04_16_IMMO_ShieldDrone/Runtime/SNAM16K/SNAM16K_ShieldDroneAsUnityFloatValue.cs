﻿using DroneIMMO;

public class SNAM16K_ShieldDroneAsUnityFloatValue : SNAM_Generic16K<STRUCT_ShieldDroneAsUnity>
{
    
}
