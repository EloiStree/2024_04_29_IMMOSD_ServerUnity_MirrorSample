﻿namespace DroneIMMO
{
    public class SNAM16K_IsGameIndexUse : SNAM16K_ObjectBool { }


}