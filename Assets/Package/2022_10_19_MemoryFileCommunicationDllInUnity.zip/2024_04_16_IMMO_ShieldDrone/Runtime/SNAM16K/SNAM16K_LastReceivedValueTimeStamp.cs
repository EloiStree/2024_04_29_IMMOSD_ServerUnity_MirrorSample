﻿namespace DroneIMMO
{
    public class SNAM16K_LastReceivedValueTimeStamp : SNAM_Generic16K<ulong> { }


    //[System.Serializable]
    //public struct IndexToIndexInteger
    //{
    //    public int m_index;
    //    public int m_value;
    //}
    //[System.Serializable]
    //public struct IndexToUlong
    //{
    //    public int m_index;
    //    public ulong m_value;
    //}
}