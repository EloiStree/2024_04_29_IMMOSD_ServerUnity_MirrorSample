using System;
using System.Collections.Generic;
using Unity.Collections;
using UnityEngine;

namespace DroneIMMO
{

    public class SNAM16K_IntegerPlayerIndexClaim : SNAM16K_ObjectInt
    {
    }
}