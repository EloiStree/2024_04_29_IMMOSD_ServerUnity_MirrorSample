﻿using DroneIMMO;

public class SNAM16K_DebugDrawLine : SNAM_Generic16K<STRUCT_DrawLineDuoPoint> { }
