﻿namespace DroneIMMO
{
    public class SNAM16K_IntegerUserValue: SNAM16K_ObjectInt { }
    
    [System.Serializable]
    public struct IntegerPlayerValue
    {
        public int m_value;
    }

  
}