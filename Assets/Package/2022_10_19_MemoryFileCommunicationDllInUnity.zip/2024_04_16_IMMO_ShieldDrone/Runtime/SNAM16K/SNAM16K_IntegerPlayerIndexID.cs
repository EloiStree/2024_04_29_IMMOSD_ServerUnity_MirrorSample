﻿namespace DroneIMMO
{
    public class SNAM16K_IntegerPlayerIndexID : SNAM_Generic16K<int> { }

   
    
}