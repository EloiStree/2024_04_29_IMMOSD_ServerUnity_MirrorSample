using DroneIMMO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class SNAM16K_DroneGamepad16K : SNAM_Generic16K<STRUCT_DroneGamepad> { }