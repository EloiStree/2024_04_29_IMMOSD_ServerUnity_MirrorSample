﻿using DroneIMMO;

public class SNAM16K_BooleanFilter : SNAM_Generic16K<bool>
{ }