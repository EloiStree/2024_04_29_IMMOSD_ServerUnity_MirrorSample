﻿[System.Serializable]
public struct STRUCT_DroneGamepad {

    public float m_leftRightRotationPercent11;
    public float m_downUpMovementPercent11;
    public float m_leftRightMovementPercent11;
    public float m_backForwardMovementPercent11;
}
