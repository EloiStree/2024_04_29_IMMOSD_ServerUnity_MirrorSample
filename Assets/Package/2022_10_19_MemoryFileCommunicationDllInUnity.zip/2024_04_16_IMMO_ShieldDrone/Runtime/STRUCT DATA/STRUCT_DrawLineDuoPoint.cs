﻿using UnityEngine;

[System.Serializable]
public struct STRUCT_DrawLineDuoPoint {

    public Vector3 m_pointA;
    public Vector3 m_pointB;

    
}



