﻿[System.Serializable]
public struct STRUCT_IndexInteger
{
    public bool m_isUsed;
    public int m_playerIndex;
    public int m_value;
    public ulong m_lastTimeStamp;
}
