﻿using Unity.Collections;
using UnityEngine;

public class BigByteArrayCompressedDrone16KMono : MonoBehaviour
{

    public byte[] GetBytesArray() { return BigByteArrayCompressedDrone16K.GetBytesArray(); }
}
