﻿public class SNAM16K_ObjectDouble : SNAM_Generic16K<double> { }



