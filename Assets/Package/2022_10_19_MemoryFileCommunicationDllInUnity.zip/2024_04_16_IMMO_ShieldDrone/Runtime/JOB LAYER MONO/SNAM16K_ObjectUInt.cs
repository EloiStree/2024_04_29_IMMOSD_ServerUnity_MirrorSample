﻿

public class SNAM16K_ObjectUInt : SNAM_Generic16K<uint> { }

