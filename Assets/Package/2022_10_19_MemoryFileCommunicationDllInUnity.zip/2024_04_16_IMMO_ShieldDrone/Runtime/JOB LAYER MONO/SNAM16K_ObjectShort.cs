﻿




public class SNAM16K_ObjectShort : SNAM_Generic16K<short> { }

