﻿public class SNAM16K_ObjectSbyte : SNAM_Generic16K<sbyte> { }



