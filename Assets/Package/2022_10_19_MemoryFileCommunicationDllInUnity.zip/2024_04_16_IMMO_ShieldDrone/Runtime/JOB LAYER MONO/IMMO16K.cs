﻿public class IMMO16K { 

    public static int ARRAY_MAX_SIZE = 128 * 128;
}
