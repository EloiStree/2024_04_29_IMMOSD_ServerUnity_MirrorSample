﻿public class SNAM16K_ObjectChar : SNAM_Generic16K<char> { }



