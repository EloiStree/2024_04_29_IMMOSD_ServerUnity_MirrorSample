﻿public class SNAM16K_ObjectFloat : SNAM_Generic16K<float> { }



