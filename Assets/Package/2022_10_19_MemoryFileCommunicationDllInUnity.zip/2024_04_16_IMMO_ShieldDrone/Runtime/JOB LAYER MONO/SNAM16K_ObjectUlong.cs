﻿public class SNAM16K_ObjectUlong : SNAM_Generic16K<ulong> { }

