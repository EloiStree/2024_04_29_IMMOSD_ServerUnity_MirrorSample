﻿


public class SNAM16K_ObjectLong : SNAM_Generic16K<long> { }

