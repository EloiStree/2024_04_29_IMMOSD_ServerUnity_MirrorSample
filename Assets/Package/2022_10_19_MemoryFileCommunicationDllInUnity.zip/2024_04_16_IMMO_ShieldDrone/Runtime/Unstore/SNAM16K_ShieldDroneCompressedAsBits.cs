﻿

public class SNAM16K_ShieldDroneCompressedAsBits : SNAM_Generic16K<STRUCT_ShieldDroneCompressedBits> { }
