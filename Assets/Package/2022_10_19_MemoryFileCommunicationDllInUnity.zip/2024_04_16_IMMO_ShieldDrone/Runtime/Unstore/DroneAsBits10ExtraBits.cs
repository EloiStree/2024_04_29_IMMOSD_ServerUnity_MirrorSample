﻿public class DroneAsBits10ExtraBits {

    public static int m_boundary_00_ceiling = 65535; //11111111 11111111 00;
    public static int m_boundary_01_ground = 65536; //01 00000000 00000000;
    public static int m_boundary_01_ceiling = 131071; //01 11111111 11111111 ;
    public static int m_boundary_10_ground = 131072; //10 00000000 00000000;
    public static int m_boundary_10_ceiling = 196607; //10 11111111 11111111;
    public static int m_boundary_11_ground = 196608; //11 00000000 00000000;
    public static int m_boundary_11_ceiling = 262143; //11 11111111 11111111;
}


