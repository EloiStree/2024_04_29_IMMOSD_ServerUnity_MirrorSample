using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PushPackMono_DroneToWebsocket : MonoBehaviour
{
    public WebsocketTargetRelay m_targetRelay;

    void Start()
    {
        
    }


    void Update()
    {
        
    }
}
