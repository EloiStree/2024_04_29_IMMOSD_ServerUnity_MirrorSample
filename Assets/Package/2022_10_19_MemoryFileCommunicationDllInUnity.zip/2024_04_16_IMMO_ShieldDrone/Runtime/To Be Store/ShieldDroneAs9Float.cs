﻿[System.Serializable]
public struct ShieldDroneAs9Float
{
    public float m_gameSate;  //  1: | 2: | 3: | 4: | 5: | 6: | 7: | 8: 0= Undefined, 1= Player online and alive 
    public float m_vx;
    public float m_vy;
    public float m_vz;
    public float m_qx;
    public float m_qy;
    public float m_qz;
    public float m_qw;
    public float m_shield;
}
