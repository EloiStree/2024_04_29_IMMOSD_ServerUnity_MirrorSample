﻿namespace DroneIMMO
{
    public class NativeGeneric16KUtility {

        public static int ARRAY_MAX_SIZE = 128 * 128;
    }
}